import './App.css';
import {
  BrowserRouter as Router,
  Routes, 
 
  Route
} from 'react-router-dom'
import Homepage from './pages/Homepage';
import Registerpage from './pages/Registerpage';
import Navbar from './components/Navbar';
import ProductDetail from './pages/ProductDetail';

// for showing toast messages
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import LoginPage from './pages/Loginpage';
import Admindashboard from './pages/AdminDashboard';
import AdminEditProduct from './pages/admin/AdminEditProduct';
import AdminRoutes from './protected/AdminRoutes';
import UserRoutes from './protected/UserRoutes';
import FeaturePage from './pages/admin/Featurepage';

function App() {
  return (
    <Router>
      <Navbar/>
      <ToastContainer/>
      <Routes>
         <Route path = "/" element = {<Homepage/>}/>   {/* //landing page and home */}
        <Route path = '/register' element = {<Registerpage></Registerpage>}/>
        <Route path = '/login' element = {<LoginPage></LoginPage>}/>
        <Route path='/product/:id' element={<ProductDetail />} />
       
        

        <Route element= {<UserRoutes/>}>
          <Route path='/profile' element = {<h1>Profile</h1>}></Route>
        </Route>
        <Route path = '/admindashboard' element = {<Admindashboard> </Admindashboard>}/>
        <Route element={<AdminRoutes/>}>

        <Route element= {<UserRoutes/>}>
          <Route path='/feature' element = {<FeaturePage/>}/>
        </Route>
       
        
        <Route path = '/admin/edit/:id' element={<AdminEditProduct/>}/>
        </Route>
      </Routes>
    </Router>
  );
}

export default App;