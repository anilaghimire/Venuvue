import React, { useState, useEffect } from 'react';
import { getAllProductsApi } from '../apis/api';
import { Link } from 'react-router-dom';
import '../style/Homepage.css'; // Importing custom CSS for HomePage styles
import homepageImage from '../images/homepage.png';

const HomePage = () => {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    getAllProductsApi()
      .then((res) => {
        setProducts(res.data.products);
      })
      .catch((error) => {
        console.error('Error fetching products: ', error);
      });
  }, []);

  return (
    <div>
    {/* Top Div with flex container and  picture */}
  
      <div className="top-div">
        <div className="flex-container">
          <img
            src={homepageImage}
            alt="homepage"
            className="homepage-image"
          />
        </div>
      </div>
   


    <div className="container">
      <h1 className="heading">FRUGAL-A convenient thrift store</h1>
      <div className="row">
        {products.map((product) => (
          <div key={product._id} className="col-md-4 mb-4">
            <div className="card">
              <img
                src={product.productImageUrl}
                className="card-img-top"
                alt={product.productName}
              />
              <div className="card-body">
                <h5 className="card-title">{product.productName}</h5>
                <p className="card-text">Rs.{product.productPrice}</p>
                <Link to={`/product/${product._id}`} className="btn btn-primary">
                  View Details
                </Link>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  
  {/* Bottom Div with Application Information */}
  <div className="bottom-div">
        <p>Location: Dillibazar
         <p> FRUGAL - A convinient thrift store </p>
        </p>
        
      </div>
    </div>

);
};

export default HomePage;
   

