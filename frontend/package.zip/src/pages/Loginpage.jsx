
import React, { useState } from 'react';
import { toast } from 'react-toastify';
import { loginUserApi } from '../apis/api';
import '../style/Login.css'; // Importing CSS file for styling

// Importing  logo image
import logo from '../images/logo.png'; 



// Add styles for the logo
const logoStyle = {
  width: '160px', // Adjusting the width as 
  height: '160px', // Adjusting the height 
  marginBottom: '2px', // Adding margin to separate the logo from other elements
};

const LoginPage = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const changeEmail = (e) => {
    setEmail(e.target.value);
  };

  const changePassword = (e) => {
    setPassword(e.target.value);
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!email || !password) {
      toast.error('Please enter both email and password.');
      return;
    }

    const data = {
      email: email,
      password: password,
    };

    loginUserApi(data)
      .then((res) => {
        if (res.data.success === false) {
          toast.error(res.data.message);
        } else {
          toast.success(res.data.message);
          localStorage.setItem('token', res.data.token);
          const jsonDecode = JSON.stringify(res.data.userData);
          localStorage.setItem('user', jsonDecode);
        }
      })
      .catch((err) => {
        toast.error('Server error');
        console.error(err.message);
      });
  };

  return (
    <div className='page-container'>
    {/* Background image container */}
    <div className='background-image'>
      {/* Logo */}
      <img src={logo} alt='Logo' style={logoStyle} />

       {/* Login container */}
       <div className='login-container'>
          <h1>Login to Your Account</h1>
          <form className='custom-form'>
            <label>Email</label>
            <input
              onChange={changeEmail}
              type='text'
              className='form-control mb-2 custom-input'
              placeholder='Enter your Email'
            />
            <label>Password</label>
            <input
         
            onChange={changePassword}
            type='password'
            className='form-control mb-3 custom-input'
            placeholder='Enter your Password'
          />
          <button onClick={handleSubmit} className='btn btn-primary w-100 mb-2 custom-btn'>
            Login
          </button>
          <p className='text-black text-decoration-none'>
            <a href='#'>Forgot Password?</a>
          </p>
        </form>
      </div>
    </div>
    </div>
  );
};


export default LoginPage;
