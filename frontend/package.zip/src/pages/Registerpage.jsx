import React, {useState} from 'react';

import Navbar from '../components/Navbar';
import { createUserApi, testApi } from '../apis/api';
import { toast } from 'react-toastify';
import '../style/Register.css';

import logo from '../images/logo.png'; 


// Add styles for the logo
const logoStyle = {
  width: '160px', // Adjust the width 
  height: '160px', // Adjust the height 
  marginBottom: '2px', // margin to separate the logo from other elements
};

const Registerpage = () => {
      //useState (Setting input value)
      const [firstName, setFirstName] = useState('')
      const [lastName, setLastName] = useState('')
      const [email, setEmail] = useState('')
      const [password, setPassword]  = useState('')
      const [confirmPassword, setConfirmPassword] = useState('')

      // userstate (setting eror message)
      const [fnameerror,setFnameError]=useState('')
      const [lnameerror,setLnameError]=useState('')
      const [emailerror,setEmailError]=useState('')
      const [passworderror,setPasswordError]=useState('')
      const [cpassworderror,setCPasswordError]=useState('')  


      //validate input value 
      const validate = () => {

        let isValid =true
        //reset error message
        setFnameError('')
        setLnameError('')
        setEmailError('')
        setPasswordError('')
        setCPasswordError('')
      

        if(firstName.trim() === ""){
          setFnameError("First Name is required")
          isValid = false
        }
        if(lastName.trim() === ""){
          setLnameError("Last Name is required")
          isValid = false
        }
        if(email.trim() === ""){
          setEmailError("Email is required")
          isValid = false
        }
        if(password.trim() === ""){
          setPasswordError("Password is required")
          isValid = false
        }
        if(confirmPassword.trim() === ""){
          setCPasswordError("Confirm Password is required")
          isValid = false
        }
        if(password.trim() !== confirmPassword.trim()){
          setCPasswordError("Password and Confirm Password must be same")
          isValid = false
        }
        return isValid
      }



      //function for changing input value
      const changeFirstname = (e) => {
        setFirstName(e.target.value)
      }
      const changeLastname = (e) => {
        setLastName(e.target.value)
      }
      const changeEmail = (e) => {
        setEmail(e.target.value)
      }
      const changePassword = (e) => {
        setPassword(e.target.value)
      }
      const changeConfirmPassword = (e) => {
        setConfirmPassword(e.target.value)
      }
      

      //function for button
      const handleSubmit = (e) => {
        e.preventDefault()

        //validate the data
        const isValid = validate()
        if(!isValid){
          return
        }

      //     //check test api
      // testApi().then((res) => {
      //   console.log(res.data);
      // })

      const data = {
        firstName : firstName,
        lastName : lastName,
        email : email,
        password : password
      }

     //making api call
    createUserApi(data).then((res) => {
      if(res.data.success == false){
        toast.error (res.data.message)
      }else{
        toast.success(res.data.message)
      }
      

    }).catch((err) => {
      toast.error("Server error")
      console.log(err.message)
    })

      };

      
      return (
        <div className='page-container'>
      <div className='background-image'>
        <img src={logo} alt='Logo' style={logoStyle} />
        <div className='registration-container'>
          <h1>Create your Account!</h1>
          <form className='m-4 w-35'>
            <label>First Name : {firstName}</label>
            {fnameerror && <span className='text-danger'>{fnameerror}</span>}
            <input
              onChange={changeFirstname}
              type='text'
              className='form-control mb-2'
              placeholder='Enter your First Name'
            />
    
              <label>Last Name</label>{lnameerror && <span className="text-danger">{lnameerror}</span>   
              }
              <input onChange={changeLastname} type='text' className='form-control mb-2' placeholder='Enter your Last Name'/>
              

              <label>Email</label>{
                emailerror && <span className="text-danger">{emailerror}</span>
              }
              <input onChange={changeEmail} type='text' className='form-control mb-2' placeholder='Enter your Email'/>

              <label>Password</label>
              {
                passworderror && <span className="text-danger">{passworderror}</span>
              }
              <input onChange={changePassword} type='password' className='form-control mb-3' placeholder='Enter your Password'/>


              <label>Confirm Password</label>
              {
                cpassworderror && <span className="text-danger">{cpassworderror}</span>
              }
              <input onChange={changeConfirmPassword} type='password' className='form-control mb-3' placeholder='Enter your Password'/>


              
              <button onClick={handleSubmit} className='btn btn-success w-100 mb-2'>
                Create an Account
              </button>
    
              <a href='' className='text-black text-decoration-none'>
                Already have an Account?
              </a>
            </form>
          </div>
        </div>
        </div>
      );
    };
    
export default Registerpage;

